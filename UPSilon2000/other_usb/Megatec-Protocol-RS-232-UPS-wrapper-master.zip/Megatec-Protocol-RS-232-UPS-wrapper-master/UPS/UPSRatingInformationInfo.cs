﻿namespace UPS
{
    using System;

    public class UPSRatingInformationInfo
    {
        public double BatteryVoltage = 0.0;
        public double Frequency = 0.0;
        public double RatingCurrent = 0.0;
        public double RatingVoltage = 0.0;
        public bool Success = false;
    }
}


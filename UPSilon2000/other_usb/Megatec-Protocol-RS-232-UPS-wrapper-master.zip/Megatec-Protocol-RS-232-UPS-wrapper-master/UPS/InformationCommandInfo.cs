﻿namespace UPS
{
    using System;

    public class InformationCommandInfo
    {
        public string Company_Name = "";
        public bool Success = false;
        public string UPS_Model = "";
        public string Version = "";
    }
}


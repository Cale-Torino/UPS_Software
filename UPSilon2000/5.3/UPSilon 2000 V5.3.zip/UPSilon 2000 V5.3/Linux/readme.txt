==========================================================================
UPSilon for Linux and FreeBSD v2.1 --UPS Monitoring & Controlling Software
==========================================================================

1.1 Operating Systems Supported
--------------------------------------------------------------------------
    * Linux 2.x
    * FreeBSD 2.x,3.x

1.2 Features
--------------------------------------------------------------------------
   +Power Crisis Management
    * Utility Failure and Battery Low Detection
    * Programmable System and UPS shutdown delay time
    * Automatic system and UPS shutdown on power outages or before battery
      exhaustion
    * Warning Messages sent to users at regular intervals prior to system
      shutdown
    * Event Messages sent to manager by email or pager
    * Unattended and scheduled system shutdown and automatic reboot
    * User-defined batch job execution before system shutdown
    * Power event notification for users and administrators
   +UPS Management
    * UPS Preventive Maintenance - Initiate Self-tests to ensure the health
      of the UPS.
    * UPS Battery Conservation - Put a network UPS on battery to sleep
      before the battery becomes depleted.
    * Turn on, turn off, reboot or put the UPS to sleep straight from your
      console.
   +POWER MANAGEMENT UTILITIES
    * Automatic installation procedure.
    * Automatic background process initialization on startup
    * Real-time graphical display of power/UPS status
    * UPS power event logging
    * Intuitive Parameter Configuration Editor
    * Batch Job Execution before System Shutdown
    * Simultaneous monitoring of several remote network UPSs
    * Automatic Communication Port name detection
    * Local monitoring through a cable attached to the system's RS232
      serial port
    * Local Network UPS monitoring through an SNMP agent (MIB OID
      {iso(1) org(3) dod(6) internet(1) private(4) enterprises(1) ppc(935)} )

1.3 System Requirements
---------------------------------------------------------------------
    * UNIX operating system running on the computer.
    * A dedicated RS232 serial port on your system.
    * A UPS with an available RS232 protocol port.
    * An SNMP Agent if you intend to monitor a network UPS.

1.4 SIMPLE INSTALLATION
---------------------------------------------------------------------
    * Hardware Installation
      1.Connect the DB-9 male connector of the cable to the UPS
        interface. (A DB-9 female connector of RS232 protocol type.).
      2.Connect the female connector of DB-9 cable to the dedicated
        RS232 serial port (If there is only a DB-25 connector on your
        computer, uses a DB-9 to DB-25 converter).
     * Software Installation
       1.Log in as the super-user.
       2.Use the 'ftp' utility in MS-DOS to copy files into the system
         directory '/tmp'.
       3.Use tar to uncompress file after the 'ftp' file transfer:
            # cd /tmp
            # tar xzvf linux-upsilon.tar.gz
            # chmod 755 install.linux
       4.Execute the installation program:
         # ./install.linux
       5.Select the target system from the menu, and configuration
         the UPSilon for UNIX(make sure no other process uses the
         same serial port), the installation program will launch the
         UPSilon for UNIX daemon process automatically.
       Note:If there is no network connection in your system, please
            let your dealer know what kind of media you could use to
            copy files into your system.
     * How to give command
       1.Start the UPSilon for UNIX daemon process
         /etc/upsilon/upsilon start
       2.Stop the UPSilon for UNIX daemon process
         /etc/upsilon/upsilon stop
       3.Configure the parameters:
         /etc/upsilon/upsilon config
       4.Event Notice by Pager
         /etc/upsilon/upsilon.pgr
       5.Event Notice by Email
         /etc/upsilon/upsilon.eml
       6.Monitor the UPS status:
         /etc/upsilon/upsilon status
       7.Send Commands Directly to the UPS
         /etc/upsilon/upsilon issuer
       8.Read Online Documentation
         /etc/upsilon/upsilon help
       9.History Information
         /etc/upsilon/rupslog

1.5 TECHNICAL SUPPORT
-------------------------------------------------------------------------
    UPSilon is developed by Mega System Technologies, Inc.If there is any
    question or comment about this product,please be free to contact us.

    Mega System Technologies, Inc.
    Tel: +886-2-87922060
    Fax: +886-2-87922066
    CompuServe ID#: 101400,362
    E-MAIL: service@megatec.com.tw
    FTP: ftp://ftp.megatec.com.tw
    WWW: http://www.megatec.com.tw
    Copyright 1996~1999 by: Mega System Technologies, Inc.

